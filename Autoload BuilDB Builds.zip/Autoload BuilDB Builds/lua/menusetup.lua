Hooks:PostHook(MenuSetup, "init_managers", "autoload_buildb_menusetup_init", function ()
	AutoloadBuilDB:autoload("MenuSetup:init_managers")
end)
