function MultiProfileManager:infamy_reset()
	--no
end